#include "funcs.h"


// 1.	Write a sort function that will sort in ascending or descending order based 
// on a comparison method passed in.The functions signature will be :
//     void sortInts(int iArray[], int iSize, COMPARER comp)
// iArray : array to be sorted,
// iSize : number of elements in the array
// comp : a function pointer of type COMPARER that compares two ints.

// Could use any sort - this example is the bubble sort
// https://www.geeksforgeeks.org/bubble-sort
void sortInts(int iArray[], int iSize, COMPARER comp)
{
	int i, j;
	for (i = 0; i < iSize - 1; i++)
	{
		// Last i elements are already in place
		for (j = 0; j < iSize - i - 1; j++)
		{
			if (comp(iArray[j], iArray[j + 1]) > 0)
			{
				int temp = iArray[j];
				iArray[j] = iArray[j + 1];
				iArray[j + 1] = temp;
			}
		}
	}
}


// 2. Some basic encrypting can be done using the XOR operator.
// Write an encrypting function with signature:
//     void Encryptor(String s, BYTE key)
// This function will loop through the string and 
// encrypt its values one char at a time using the key and the XOR bit operator
void Encryptor(String s, BYTE key)
{
	while (*s) // *s != '\0'
	{
		*s ^= key;
		s++;
	}
}


// a. A function that will loop through each row of the array
// and call a function pointer on each row.
//     void twoDArrayRowModifier(int** iArray, int iNumRows, ROW_FUNC rf, int iRowSize);
// The first parameter is the 2D array, and ROW_FUNC is a typedefed function pointer
// that operates on each row.
// For each row, call the function pointer passing in the current row.
// Note that since the row might be modified, assign the return value from rf 
// back to the current row.
void twoDArrayRowModifier(int** iArray, int iNumRows, ROW_FUNC rf, int iRowSize)
{
	for (int i = 0; i < iNumRows; i++)
	{
		iArray[i] = rf(iArray[i], iRowSize);
	}
}
