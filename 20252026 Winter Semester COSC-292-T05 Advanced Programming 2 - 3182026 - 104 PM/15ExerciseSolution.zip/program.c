#include <stdio.h>
#include <stdlib.h>
#include "funcs.h"


int compareToAsc(int a, int b)
{
	return a - b;
}


int compareToDes(int a, int b)
{
	return b - a;
}


void printArray(int* iArray, int iSize)
{
	for (int i = 0; i < iSize; i++)
	{
		printf("%d ", iArray[i]);
	}
	printf("\n");
}


void testSorter()
{
	int iData[] = { -45, 56, 62, 30, 2 };
	int iSize = sizeof(iData) / sizeof(int);

	printf("Original data: ");
	printArray(iData, iSize);

	// When called, pass in one of the two compareTo methods:
	sortInts(iData, iSize, compareToAsc);
	printf("Sorted ascending: ");
	printArray(iData, iSize);

	sortInts(iData, iSize, compareToDes);
	printf("Sorted descending: ");
	printArray(iData, iSize);
}


void testEncryptor()
{
	//Encrypting key can be any character.
	BYTE key = '&';
	char cMessage[] = "Rob Miller";

	//Calling the method the first time will encrypt the string.
	Encryptor(cMessage, key);
	
	//Note, some characters may be converted to one of the "unprintable" characters.
	//In this case, printing the message may produce garbled results.
	printf("Encrypted message is %s\n", cMessage);
	
	//Calling the method a second time will decrypt the message.
	Encryptor(cMessage, key);
	printf("Decrypted message is %s\n", cMessage);
}


// Create a new row using malloc.
// Return the pointer to the row.
int* createRows(int* iPtr, int iRowSize)
{
	return (int*)malloc(iRowSize * sizeof(int));
}


//Print the values of the current row.
int* printRows(int* iPtr, int iRowSize)
{
	printArray(iPtr, iRowSize);
	return iPtr;
}


//Free the row and return null
int* freeRows(int* iPtr, int iRowSize)
{
	free(iPtr);
	return NULL;
}


// BONUS FUNCTION NOT GIVEN IN EXERCISE DOCUMENT
// Assign values to each row
int* enterRowData(int* iPtr, int iRowSize)
{
	for (int i = 0; i < iRowSize; i++)
	{
		// iPtr[i] = i;
		printf("Enter integer value %d for current row: ", (i + 1));
		scanf("%d", iPtr + i); // or &iPtr[i]
	}
	return iPtr;
}


// BONUS FUNCTION NOT GIVEN IN EXERCISE DOCUMENT
// Double the values in each row
int* doubleRows(int* iPtr, int iRowSize)
{
	for (int i = 0; i < iRowSize; i++)
	{
		*(iPtr + i) *= 2; // or iPtr[i] *= 2;
	}
	return iPtr;
}


void testTwoDArray()
{
	int** iArray;
	int iNumRows = 3;
	int iRowSize = 4;

	iArray = (int**)malloc(iNumRows * sizeof(int*));

	//Create each row
	twoDArrayRowModifier(iArray, iNumRows, createRows, iRowSize);

	// BONUS FUNCTION NOT GIVEN IN EXERCISE DOCUMENT
	// Assign values to each row
	twoDArrayRowModifier(iArray, iNumRows, enterRowData, iRowSize);

	// BONUS FUNCTION NOT GIVEN IN EXERCISE DOCUMENT
	// Double the values in each row
	twoDArrayRowModifier(iArray, iNumRows, doubleRows, iRowSize);

	//Print each row
	twoDArrayRowModifier(iArray, iNumRows, printRows, iRowSize);

	//Free each row
	twoDArrayRowModifier(iArray, iNumRows, freeRows, iRowSize);
	
	// Free the array of pointers
	free(iArray);
	iArray = NULL;
}


int main(void)
{
	testSorter();
	testEncryptor();
	testTwoDArray();

	return EXIT_SUCCESS;
}
