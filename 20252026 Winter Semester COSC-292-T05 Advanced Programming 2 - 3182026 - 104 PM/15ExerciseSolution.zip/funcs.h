#ifndef FUNCS_H
#define FUNCS_H

typedef int (*COMPARER)(int, int);
// Use typedefs to create String(char*) and BYTE(unsigned char)
typedef unsigned char* String;
typedef unsigned char BYTE;
// b.	A typedefed function pointer that returns an int * 
// and takes an int * (current row) and an int (row size)
typedef int* (*ROW_FUNC)(int*, int);

void sortInts(int iArray[], int iSize, COMPARER comp);
void Encryptor(String s, BYTE key);
void twoDArrayRowModifier(int** iArray, int iNumRows, ROW_FUNC rf, int iRowSize);

#endif // !FUNCS_H
