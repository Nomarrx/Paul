#include <stdio.h>
#include <malloc.h> // Memory allocation - required for DMA
#include <string.h>
#include "dma.h"


// Function to print an array of ints
void printInts(int* iBufferPtr, int iSize)
{
	printf("The integers are: ");
	for (int i = 0; i < iSize - 1; i++)
	{
		printf("%d, ", *(iBufferPtr++));
	}
	printf("%d\n", *iBufferPtr);
}


int* getInts(int iNumInts)
{
	/*
	Create memory space for the integers using the function malloc.
	malloc takes the size of memory in bytes as an argument.
	malloc returns a pointer to the first byte of the requested memory.
	malloc returns a (void*) void pointer, which is still a pointer,
	just no associated type. Usually, a cast is required.
	The content of the newly allocate block of memory is not initialized
	(use memset if you want - memset is a function that initializes a block of memory).
	*/
	int* iBufferPtr = (int*)malloc(iNumInts * sizeof(int));
	//memset(iBufferPtr, '\0', iNumInts * sizeof(int));

	// Load data into the array
	for (int i = 0; i < iNumInts; i++)
	{
		printf("Enter integer %d: ", (i + 1));
		scanf_s("%d", iBufferPtr + i);
	}

	return iBufferPtr;
}


// Add an int to the end of a dynamic array
// Purpose --> Takes an array, increases its size by one. Asks the user for an int
//				and adds it to the end.
// iArrayPtr --> The original dynamically allocated array
// iSizePtr --> Pointer to the original size of the array.
//				Used to increase the passed-in size.
// Note: The array originally passed in is freed after its contents are copied
int* addInt(int* iArrayPtr, int* iSizePtr)
{
	// Create a new array
	int* iNewPtr = (int*)malloc((*iSizePtr + 1) * sizeof(int));

	// Copy data from the old array to the new array using the memcpy function
	memcpy(iNewPtr, iArrayPtr, (*iSizePtr) * sizeof(int));

	// Free the original array. If we don't, we are creating a "memory leak".
	// Eventually, memory leaks can cause a system to stop.
	free(iArrayPtr);
	iArrayPtr = NULL;

	// Add new int to the end of the new array
	printf("Enter another integer: ");
	scanf_s("%d", iNewPtr + *iSizePtr);

	// Increment the size
	(*iSizePtr)++;

	return iNewPtr;
}


// Return a pointer to a dynamically allocated string or NULL if it fails
char* getStringDynamic(const char* cPrompt)
{
	// Pointer to a dynamically allocated string
	char* cTempPtr = NULL;
	// Pointer to a dynamically allocated array of exact size required
	char* cReturnPtr = NULL;
	int iSizeDestination = 0;

	cTempPtr = (char*)malloc(MAX_STRING_SIZE * sizeof(char));

	// If memory was allocated (malloc can fail, and if it does, it returns NULL)
	if (cTempPtr) // same as (cTempPtr != NULL)
	{
		// Prompt the user for a string
		printf("%s", cPrompt);
		// Scan in the string using fgets (safer than gets because it limits size)
		fgets(cTempPtr, MAX_STRING_SIZE, stdin);

		cTempPtr[strlen(cTempPtr) - 1] = '\0'; // to get rid of the '\n' fgets reads in

		// Allocate a new buffer based on the actual size of the input
		// Always remember to allocate space for the null terminator
		iSizeDestination = strlen(cTempPtr) + 1;
		cReturnPtr = (char*)malloc(iSizeDestination * sizeof(char));

		if (cReturnPtr)
		{
			// Copy the data from temp array to return array
			strcpy_s(cReturnPtr, iSizeDestination, cTempPtr);
		}

		free(cTempPtr);
		cTempPtr = NULL;
	}

	return cReturnPtr;
}


char* getNameAndSIN()
{
	// dynamically allocate space for a name of some MAX_NAME_SIZE plus an int for the SIN#
	char* cNameAndSINPtr = (char*)malloc(sizeof(char) * MAX_NAME_SIZE + sizeof(int));
	int iLength;

	if (cNameAndSINPtr)
	{
		// Read in the name
		printf("Enter the name: ");
		fgets(cNameAndSINPtr, MAX_NAME_SIZE, stdin);

		// fgets puts in the newline character which we might not want.
		// You can overwrite it with a null terminator.
		iLength = strlen(cNameAndSINPtr);
		if (cNameAndSINPtr[iLength - 1] == '\n')
		{
			cNameAndSINPtr[iLength - 1] = '\0';
		}

		// Read in the SIN#
		printf("Read in the SIN#: ");
		scanf_s("%d", (int*)(cNameAndSINPtr + MAX_NAME_SIZE));
	}

	return cNameAndSINPtr;
}


void printNameAndSIN(char* cBuffer)
{
	int* iSINPtr = (int*)(cBuffer + MAX_NAME_SIZE);
	printf("The name is %s\n", cBuffer);
	printf("The SIN# is %d\n", *iSINPtr);
}


char* concatenateString(const char* cFirstPtr, const char* cSecondPtr)
{
	int iLengthFirst = strlen(cFirstPtr);
	int iLengthSecond = strlen(cSecondPtr);

	// Note that we must include space for the null terminator
	char* cReturnString = (char*)malloc(iLengthFirst + iLengthSecond + 1);

	if (cReturnString)
	{
		// Just to be safe, initialize our string to empty
		cReturnString[0] = '\0';

		// Copy the first string to destination
		strcpy_s(cReturnString, iLengthFirst + 1, cFirstPtr);

		// Copy the second string to the end of the first string
		//strcat(cReturnString, cSecondPtr);
		strcpy_s(cReturnString + iLengthFirst, iLengthSecond + 1, cSecondPtr);
	}

	return cReturnString;
}
