#ifndef DMA_H
#define DMA_H

#define MAX_STRING_SIZE	255
#define MAX_NAME_SIZE	30

// Function to print an array of ints
void printInts(int*, int);

// Return an array of integers that are dynamically allocated
int* getInts(int);

// Add an int to the end of a dynamic array
int* addInt(int*, int*);

// Get a dynamic string (or NULL if it fails)
char* getStringDynamic(const char*);

// A function that creates a buffer with a name (MAX_NAME_SIZE) and SIN#
char* getNameAndSIN();

// A function to display a name and SIN#
void printNameAndSIN(char* cBuffer);

// A function to concatenate two strings. No memory is freed within the function.
// Returns a dynamically allocated string.
char* concatenateString(const char*, const char*);

#endif // !DMA_H
