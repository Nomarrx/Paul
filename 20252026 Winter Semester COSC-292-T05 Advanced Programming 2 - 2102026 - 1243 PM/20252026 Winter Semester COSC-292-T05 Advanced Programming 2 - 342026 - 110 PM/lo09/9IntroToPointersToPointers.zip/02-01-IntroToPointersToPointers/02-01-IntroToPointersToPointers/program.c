#include <stdio.h>
#include <stdlib.h>

// Pointers store an address.
// Pointers are also stored in memory, so they have an address.
// Thus, we can store a pointer to a pointer (which stores the address of a pointer).

// Let's start by looking at a function that doesn't require pointers to pointers
/*
* Function: count_chars
* Purpose: counts the number of a given character in a given string
* Parameters: cPtr - pointer to the string to count the characters in
*             cSeek - character to count
* Returns: number of times that the given character appears in the given string
* Assumptions: cPtr is a null-terminated string
*/
int count_chars(const char* cPtr, char cSeek)
{
	int iCount = 0;

	while (*cPtr != '\0')
	{
		if (*cPtr == cSeek)
		{
			iCount++;
		}
		cPtr++;
	}

	return iCount;
}


// What if we want to return the position of the last occurrence of a given character
// in a given string?
// We will return a pointer to that final occurrence
/*
* Function: find_last_char
* Purpose: finds the last position of a given character in a given string
* Parameters: cPtr - pointer to the string to find the character in
*             cSeek - character to find
* Returns: a pointer with the last position of the given character in the given string
* Assumptions: cPtr is a null-terminated string
*/
char* find_last_char(const char* cPtr, char cSeek)
{
	char* cFoundPtr = NULL;

	while (*cPtr != '\0')
	{
		if (*cPtr == cSeek)
		{
			cFoundPtr = cPtr;
		}
		cPtr++;
	}

	return cFoundPtr;
}


// What if we want to do both things at once? We haven't learned about structs yet, so
// we can't return two things. But we can change the pointer by passing in its address.
/*
* Function: count_and_find_last
* Purpose: Count the number of a given character in a given string
*  and change a given pointer to the address of the last occurrence of the character
* Parameters: cPtr - string to count the characters in and find the last position in
*			  cSeek - character to count and find
*			  cPtrToLastPtr - a pointer to a pointer to be changed to the last position
* Returns: the count of the given character in the given string
* Changes: the pointer whose address is given in cPtrToLastPtr
* Assumptions: cPtr is a null-terminated string
*/
int count_and_find_last(const char* cPtr, char cSeek, char** cPtrToLastPtr)
{
	int iCount = 0;
	*cPtrToLastPtr = NULL;  // dereferences pointer to a pointer
							// to set original pointer to NULL

	while (*cPtr != '\0')
	{
		if (*cPtr == cSeek)
		{
			iCount++;
			*cPtrToLastPtr = cPtr;  // dereferences a pointer to a pointer
									// allows us to set the original pointer
		}
		cPtr++;
	}

	return iCount;
}


int main()
{
	char cTestString[] = "It's a beautiful day, isn't it?";
	int iCount;
	char* cLastPosition = NULL;

	iCount = count_chars(cTestString, 'b');
	printf("Count was %d\n", iCount);
	
	printf("String is at position %p\n", cTestString);
	cLastPosition = find_last_char(cTestString, 'b');
	if (cLastPosition != NULL)
	{
		printf("Character found was '%c' at position %p\n", *cLastPosition, cLastPosition);
	}
	else
	{
		printf("Character was not found, so pointer is %p\n", cLastPosition);
	}

	cLastPosition = NULL;
	iCount = count_and_find_last(cTestString, 'b', &cLastPosition);
	printf("\nCount was: %d\n", iCount);
	if (cLastPosition != NULL)
	{
		printf("Character found was '%c' at position %p\n", *cLastPosition, cLastPosition);
	}
	else
	{
		printf("Character was not found, so pointer is %p\n", cLastPosition);
	}

	return EXIT_SUCCESS;
}
