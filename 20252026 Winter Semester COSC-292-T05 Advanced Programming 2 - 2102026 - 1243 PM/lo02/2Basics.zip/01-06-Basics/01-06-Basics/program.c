#include <stdio.h>
#include <stdlib.h>

/* Comments: can be written as multi-line comments between
   slash-star and star-slash (only form of comments in original C) */
// Later versions of C allow single-line comments with //

// #include is pre-processor directive
// The pre-processor reads the source file looking for directives (starting with #)
// In this case, #include tells the pre-processor to find stdio.h
// and substitute its text into this file

// #include is similar to "Using" statements in C# or "import" in Java
// Tells the pre-processor that there is some existing code that we want to use
// Note that <> tell the pre-processor to look in the built-in standard libraries
// We will use "" instead of <> to look in the local project first

// Another type of pre-processor directive is the define statement (note: no semicolon)
#define PI 3.141519f


void primitiveTypes()
{
	char c = 'A'; // character literals are in single quotes
	int x = 4276803;
	float f = PI;
	double d = 12345.6579;

	// Print the value of the variables using format specifiers that start with %
	printf("The value of c is %c\n", c);
	printf("The value of c as an int is %d\n", c);
	printf("The value of x is %d\n", x);
	printf("The value of x as a character is %c\n", x);
	printf("The value of x in hex is %x\n", x);
	// Can use the format specifier to modify output
	// For instance, to display 10 characters with 2 decimals
	printf("The value of d is %10.2f\n", d);

	// What are the size of each data type on our system? (may vary with system)
	// The sizeof() function is used to return the size of a data type, struct, array, etc.
	// Measured in bytes
	printf("The size of a char is %zu\n", sizeof(c));
	printf("The size of an int is %zu\n", sizeof(x));
	printf("The size of a float is %zu\n", sizeof(float));
	printf("The size of a double is %zu\n", sizeof(double));
}


void modifiers()
{
	// Note that C defaults to signed values (can be + or -)
	// except for char, which is system-dependent
	unsigned char e = 255; // unsigned char can store values from 0 to 255
	signed char c = 127; // signed char can store values from -128 to 127

	// "short" and "long"
	short int x; // will be 2 bytes on this platform
	short y; // short form for writing a short int
	long int z; // no effect on this platform
	// Note that the only guarantees are that short <= int <= long
	// and that short must be at least 16 bits and long must be at least 32 bits

	long float f; // doubles the size to 8 bytes (same as double)
	long double d; // no effect on this platform (same as double)

	// Add 1 to e and c
	e = e + 1;
	c += 1;

	printf("The value of e is %d\n", e);
	printf("The value of c is %d\n", c);

	printf("Size of short: %zu %zu\n", sizeof(x), sizeof(y));
	printf("Size of long: %zu\n", sizeof(z));
	printf("Size of long float: %zu\n", sizeof(f));
	printf("Size of long double: %zu\n", sizeof(d));
}


void castDemo()
{
	int x;
	float y = 3.2f;
	float fahr = 115;
	float celc; // Note that uninitialized values may have random numbers

	// Assign y to x
	x = (int)y; // explicitly cast
	printf("The value of x is %d\n", x);

	// Temperature conversion
	printf("The temperature in Fahrenheit is %f\n", fahr);
	celc = ((float)5 / 9) * (fahr - 32); // cast to avoid integer division
	printf("The temperature in Celsius is %f\n", celc);
}


void demoConstants()
{
	// Note keyword const
	const float pi = 3.14159f;
	//pi = pi + 1; // cannot change the value
	printf("The value of pi is %f\n", pi);
}


// Strings in C --> Wait a minute! There are no string objects in C.
void stringDemo()
{
	char myChar = 'm'; // single quotes for a character literal
	char s1[] = "William"; // Can initialize a string literal to a char []
	char s2[5];
	//s2 = "John"; // can't do assignment
	
	s2[0] = 'J'; // arrays start at 0 are referenced with []
	s2[1] = 'o';
	s2[2] = 'h';
	s2[3] = 'n';
	// You must remember to null terminate your strings
	s2[4] = '\0';

	printf("The value of myChar is %c\n", myChar);
	printf("The value of s1 is %s\n", s1);
	// can use sizeof on an array defined in the current function
	printf("The size of s1 is %zu\n", sizeof(s1)); // includes \0, null terminator
	
	printf("The value of s2 is %s\n", s2);
	printf("The size of s2 is %zu\n", sizeof(s2));
}


void booleanDemo()
{
	int a = 3;
	int i; // C does not have built-in Boolean values
	char s3[10] = "Test";
	char* cPtr = NULL; // pointer to a character - stores the address of a character

	printf("%d\n", (a > 3)); // boolean values are integers - 0 for false
	printf("%d\n", (a <= 3)); // 1 for true
	if (a) // any non-zero integer is true
	{
		printf("True\n");
	}

	printf("Size of s3 is %zu\n", sizeof(s3));

	for (i = 0; s3[i]; i++) // same as s3[i] != '\0'
	{
	}

	printf("The length of the string is %d\n", i); // # of non-null characters in string

	cPtr = s3; // assigns the address of s3 to the pointer
	printf("The address of s3 is %p\n", &s3); // & is the address of operator here
	printf("The value of cPtr is %p\n", cPtr);
	printf("The value that cPtr is pointing to is %c\n", *cPtr); // * dereferences cPtr
	printf("The first value in s3 is %c\n", s3[0]);
	printf("The first value in s3 is %c\n", *s3); // can dereference an array

	for (i = 0; *cPtr; i++)
	{
		printf("The current value pointed to by cPtr is %c\n", *cPtr);
		printf("The value of cPtr is %p\n", cPtr);
		cPtr++; // cPtr points to the next char
				// (in other words, add 1 to the address in cPtr)
	}

	printf("The length of the string is %d\n", i);
}


// Program starts with the main function
int main(int argc, char* argv[])
{
	// Use printf to output to the console
	printf("Hello");
	printf(" world\n"); // \n specifies a newline

	//primitiveTypes();
	//modifiers();
	//castDemo();
	//demoConstants();
	//stringDemo();
	booleanDemo();

	return EXIT_SUCCESS; // defined in stdlib.h
}
