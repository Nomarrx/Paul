#include <stdio.h>
#include <string.h>
#include "array_pointers.h"


void intArrayPrinter(int iArrayPtr[], int iSize)
{
	printf("The address stored in iArrayPtr in the function is \t%p\n", iArrayPtr);
	printf("The address of iArrayPtr in the function is \t\t%p\n", &iArrayPtr);

	for (int i = 0; i < iSize; i++)
	{
		printf("The loop counter is %d and the array value is %d"
			" and the value's address is %p\n",
			i, iArrayPtr[i], &iArrayPtr[i]);
	}
}


void intArrayPrinterWithPointer(int* iArrayPtr, int iSize)
{
	for (int i = 0; i < iSize; i++)
	{
		// To retrieve the value where the pointer points, we "dereference" it
		// using the dereference operator *
//		printf("The loop counter is %d and the array value is %d"
//			" and the value's address is %p\n",
//			i, *(iArrayPtr + i), iArrayPtr + i);
		// The notation *(iArrayPtr + i) is exactly the same as iArrayPtr[i]
		// Note that because iArrayPtr is int*, we add i * sizeof(int) each time

		// You could also "walk" the pointer through the array.
		printf("The loop counter is %d and the array value is %d"
			" and the value's address is %p\n",
			i, *iArrayPtr, iArrayPtr);
		iArrayPtr++; // increment iArrayPtr by sizeof(int), so move to next array element
	}
	// The pointer will point past the end of the array when the loop is complete
	printf("The final value of iArrayPtr is %p\n", iArrayPtr);
}


void charArrayPrinterWithPointer(char* cArrayPtr)
{
	printf("The address of cArrayPtr is \t%p\n", &cArrayPtr);
	// Note that the string literal is stored in the text segment (also where function is)
	printf("The address of the string literal in cArrayPtr is \t%p\n", cArrayPtr);
	printf("The character at the address in cArrayPtr is \t%x\n", *cArrayPtr);
	printf("The address of the charArrayPrinterWithPointer function is \t%p\n",
		charArrayPrinterWithPointer);
	// Try to write to the string literal (that is, the text segment):
//	*cArrayPtr = 'A';
	// Cannot do this - you should never try to alter data in the text segment

	//while (*cArrayPtr != '\0')
	//{
	//	printf("%c", *cArrayPtr);
	//	cArrayPtr++;
	//}
	//printf("\n");

	while (*cArrayPtr)
	{
		putchar(*cArrayPtr++);
		// putchar outputs a character to stdout.
		// ++ operates on the cArrayPtr because of the order of operations
		// https://en.cppreference.com/w/c/language/operator_precedence
		// but we dereference it before adding one because it is post-increment.
		// ++ moves to the next character because cArrayPtr is char*.
	}
	putchar('\n');
}


// Will print out an int byte by byte
void intBytePrinter(int iValue)
{
	// With a char pointer, we can work one byte at a time
	char* cPtr = (char*) &iValue;

	for (int i = 0; i < sizeof(int); i++)
	{
		printf("The byte value is %x and the character equivalent is %c\n", *cPtr, *cPtr);
		cPtr++;
	}
}


// Encode some data into a double. The double is just an 8-byte buffer in this case.
// We will store a 3-letter name, an age in one byte, followed by a student loan amount
// in two bytes.
double encode()
{
	// Allocate the buffer
	double x = 0.0;
	char* cNamePtr = (char*)&x;

	// Prompt the user for input
	printf("Enter a 3-letter name: ");
	scanf_s("%3s", cNamePtr, NAME_SIZE);

	// Enter an age
	printf("Enter an age (less than 128): ");
	scanf_s("%d", (int*)(cNamePtr + NAME_SIZE));

	// Enter the student loan amount
	printf("Enter your student loan as an integer <= 65535: ");
	scanf_s("%hu", (unsigned short*)(cNamePtr + NAME_SIZE + AGE_SIZE));

	return x;
}


void decode(double x)
{
	// Pointer to the name
	char* cNamePtr = (char*)&x;
	unsigned short* loanPtr = (unsigned short*)(cNamePtr + NAME_SIZE + AGE_SIZE);

	// Print the string
	printf("The name is %s\n", cNamePtr);
	// Dereference the pointer to retrieve the single byte representing the age
	printf("The age is %d\n", *(cNamePtr + NAME_SIZE));
	// Print the student loan
	printf("The student loan is %hu\n", *loanPtr);
}


void printStringAsInts(char* cBuffer) {
	int iStringSize = strlen(cBuffer) + 1; // add 1 for the null terminator
	int iNumInts = iStringSize / sizeof(int); // number of ints in string using int division
	int* iPtr = (int*)cBuffer; // integer pointer to start of string
	int i;

	int iRemainingBytes = iStringSize % sizeof(int); // bytes left after integer division
	int iNewInt = 0; // contains last int with bytes left after integer division
	char* cLastBytesPtr = NULL;
	char* cBuildInt = NULL;

	for (i = 0; i < iNumInts; i++)
	{
		printf("%x \t%d\n", *iPtr, *iPtr); // or could use iPtr[i] without walking pointer
		intBytePrinter(*iPtr); // to test if it is converted properly
		iPtr++;
	}

	// Limitation of the above: only prints out 4-byte chunks.
	// What if the string isn't evenly divisible by 4?
	// Can't just print another int - could exceed buffer space
	// or go into undefined characters.
	// Could build another int as follows:
	if (iRemainingBytes > 0)
	{
		cLastBytesPtr = (char*)iPtr; // Character pointer to bytes remaining
		cBuildInt = &iNewInt; // Point to new integer to build that integer

		for (i = 0; i < iRemainingBytes; i++)
		{
			*cBuildInt = *cLastBytesPtr; // Add remaining byte to new integer
			// Move to next byte
			cLastBytesPtr++;
			cBuildInt++;
		}
		printf("%x \t%d\n", iNewInt, iNewInt);
		intBytePrinter(iNewInt);
	}
}
