#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "array_pointers.h"

#define BUFFER_SIZE	256


void testIntArray()
{
	int iArray[] = {2, 7, 9}; // initialize int array using {}
	// Calculate the size of the array
	int iSize = sizeof(iArray) / sizeof(int);

	printf("The address of iArray in the calling function is \t%p\n", iArray);

	// Practice: Call a function named intArrayPrinter in a separate source file named
	// array_pointers.c (with an appropriate header file). The function should loop
	// through the array, printing each value on a separate line.
	intArrayPrinter(iArray, iSize);
	printf("\n");
	intArrayPrinterWithPointer(iArray, iSize);
}


void testCharArrayPrintPointer()
{
	charArrayPrinterWithPointer("Hello cruel world");
	// Write a function charArrayPrinterWithPointer in array_pointers.c
	// Use a pointer to move along one character at a time until you reach the
	// end of the string, dereferencing the pointer to display the character
	// at each location. You can use printf("%c", value); or putchar(value);
}


void testIntBytePrinter()
{
	int x = 2189640;
	intBytePrinter(x);
}


testEncodeDecode()
{
	double x = encode();
	printf("%g\n", x);
	decode(x);
}


// First, have the user enter a string including spaces.
// Then call a function called printStringAsInts in array_pointers.c that will
// take in a string and print it out as ints (both in hex and in decimal).
// Hint: look up the strlen function (google "Microsoft strlen").
// Consider what limitations your function might have.
void testStringToInts()
{
	// Test "abcdefgh" and you should get the hex values
	// 64636261 and 68676665 or the decimal values
	// 1,684,234,849 and 1,751,606,885

	// Test "I/O" and should get the hex value
	// 4F2F49 or the decimal value
	// 5,189,449

	// or try running each of your ints through the intBytePrinter function
	// to see that you get back the original string


	char cBuffer[BUFFER_SIZE];
	int iStringSize;

	// To get a string with spaces, we need to use gets or gets_s or fgets.
	// fgets gets a string from the designated input stream up to newline 
	// or up to the number of characters specified, but includes the newline.
	printf("Enter a string to convert to integers: ");
	fgets(cBuffer, BUFFER_SIZE, stdin);

	// gets rid of the newline
	iStringSize = strlen(cBuffer);
	if (cBuffer[iStringSize - 1] == '\n')
	{
		cBuffer[iStringSize - 1] = '\0';
	}

	printStringAsInts(cBuffer);
}


int main()
{
	//testIntArray();
	//testCharArrayPrintPointer();
	//testIntBytePrinter();
	//testEncodeDecode();
	testStringToInts();

	return EXIT_SUCCESS;
}
