#ifndef ARRAY_POINTERS_H
#define ARRAY_POINTERS_H

#define NAME_SIZE	4
#define AGE_SIZE	1


// The formal argument is optional
void intArrayPrinter(int[], int);
// We can also show the argument names
void intArrayPrinterWithPointer(int* iArrayPtr, int iSize);
void charArrayPrinterWithPointer(char*);
void intBytePrinter(int);
double encode();
void decode(double x);
void printStringAsInts(char*);

#endif // !ARRAY_POINTERS_H
