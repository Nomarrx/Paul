#include <stdio.h>
#include <stdlib.h>
#include "file_io.h"


void testOpenClose()
{
	int iErr = demoOpenClose("foo.txt", "r");
	printf("The error number returned was %d\n", iErr);
}


void testRead()
{
	int iErr = demoRead("foo.txt", "r");
	printf("The error number returned was %d\n", iErr);
}


void testWrite()
{
	int iErr = demoWrite("foobar.txt", "w", "abcdefghi");
	printf("The error number was %d\n", iErr);
}


void testWriteBinary()
{
	int x = 123456789;
	//char string[] = "Hello";
	//int iErr = demoWriteBinary("foobar.bin", "wb", (int*)string);
	int iErr = demoWriteBinary("foobar.bin", "wb", &x);
	printf("The number that was passed in (in hex) was %x\n", x);
	printf("The error number returned was %d\n", iErr);
}


void testExerciseWrite()
{
	exerciseBinaryWrite("exercise.dat", "wb");
}


void testExerciseRead()
{
	int iSin = 0;
	printf("Enter the SIN# of the person to find: ");
	scanf("%d", &iSin);
	exerciseBinaryRead("exercise.dat", "rb", iSin);
}


int main()
{
	//testOpenClose();
	//testRead();
	//testWrite();
	//testWriteBinary();

	//testExerciseWrite();
	testExerciseRead();

	return EXIT_SUCCESS;
}
