#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include "file_io.h"


// Study errno.h on Wikipedia before proceeding.
// Essentially, there is a global variable called errno that gets set to indicate an
// error. See also strerror function to get a message associated with errno.
int demoOpenClose(const char* cFileName, const char* cFileMode)
{
	// Pointer to a file stream
	FILE* filePtr = NULL;

	// A variable to store potential error code
	int iErr = EXIT_SUCCESS;

	// Use fopen to open a file. Note that it returns a FILE pointer that must be 
	// assigned. If it fails, it returns a NULL and sets the errno variable to indicate
	// an error.
	// Parameters are a const char * indicating a path/filename
	// and a const char * indicating the mode (read, write, append, etc.).
	// See the document on OneDrive for various modes
	filePtr = fopen(cFileName, cFileMode);
	if (filePtr != NULL)
	{
		// Successfully opened the file
		// Close the file when done
		fclose(filePtr);
		printf("%s was successfully opened and closed.\n", cFileName);
	}
	else
	{
		iErr = errno;
		printf("Error accessing file %s: %s\n", cFileName, strerror(iErr));
	}

	return iErr;
}


int demoRead(const char* cFileName, const char* cFileMode)
{
	// Pointer to a file stream
	FILE* filePtr = NULL;

	// A variable to store potential error codes
	int iErr = EXIT_SUCCESS;

	// Create two variables on one line
	int intChar, retVal;
	char cBuffer[MAX_SIZE];
	char* retPtr = NULL;

	/*
	All read operations read data from the file to the memory location indicated (cBuffer).
	Only fgets adds an additional null terminator to the data in the buffer.
	Return types vary so testing for success depends on the function used.
	fscanf/fread - return number of times assigned or read
	 fscanf returns EOF if if a failure occurs before the first assignment
	fgets - returns a pointer to the string read or NULL
	fgetc - returns the character or EOF
	*/
	if ((filePtr = fopen(cFileName, cFileMode)) != NULL)
	{
		// Some various ways of reading from a file
		//retVal = fscanf(filePtr, "%s", cBuffer); // Quits reading at first space
		//retPtr = fgets(cBuffer, MAX_SIZE, filePtr);
		//intChar = fgetc(filePtr);
		retVal = fread((void*)cBuffer, sizeof(char), 2, filePtr);

		if (retVal > 0)
		//if (retPtr != NULL)
		//if (intChar != EOF)
		{
			printf("retVal: %d\n", retVal);
			//printf("retPtr: %p\n", retPtr);
			//printf("cBuffer: %p\n", cBuffer);
			printf("%s\n", cBuffer);
			//printf("intChar: %d\n", intChar);
			//printf("%c\n", intChar);
		}
		else // failed to read
		{
			// Check if the file stream has an error using the ferror function
			if (iErr = ferror(filePtr))
			{
				printf("Error reading from the file %s: %s\n", cFileName, strerror(iErr));
			}
			else // No message, display a generic message
			{
				printf("Could not retrieve data\n");
			}
		}

		fclose(filePtr);
	}
	else // failed to open the file
	{
		iErr = errno;
		printf("Error accessing the file %s: %s\n", cFileName, strerror(iErr));
	}

	return iErr;
}


int demoWrite(const char* cFileName, const char* cFileMode, const char* cDataPtr)
{
	FILE* filePtr = NULL;
	int iErr = EXIT_SUCCESS;
	// Number of writes
	int retVal;

	if ((filePtr = fopen(cFileName, cFileMode)) != NULL)
	{
		// fwrite
		// fprintf
		// fputs
		// fputc

		//retVal = fwrite((void*)cDataPtr, sizeof(char), strlen(cDataPtr), filePtr);
		//retVal = fprintf(filePtr, "%s\nHi\n", cDataPtr);
		//retVal = fputs(cDataPtr, filePtr); // returns 0 if successful
		retVal = fputc(cDataPtr[0], filePtr);

		if (retVal > 0) // if successful
		//if (retVal == 0) // check for success for fputs
		{
			printf("File written: %s\n", cFileName);
			printf("retVal: %d\n", retVal);
		}
		else // failed to write
		{
			if (iErr = ferror(filePtr))
			{
				printf("Error writing to file %s: %s\n", cFileName, strerror(iErr));
			}
			else
			{
				printf("Could not write the data\n");
			}
		}

		// Close the file when done
		fclose(filePtr);
		printf("%s was successfully opened and closed.\n", cFileName);
	}
	else // failed to open file for writing
	{
		iErr = errno;
		printf("Error accessing the file %s: %s\n", cFileName, strerror(iErr));
	}

	return iErr;
}


int demoWriteBinary(const char* cFileName, const char* cFileMode, const int* iDataPtr)
{
	FILE* filePtr = NULL;
	int iErr = EXIT_SUCCESS;
	// Number of writes
	int retVal;

	if ((filePtr = fopen(cFileName, cFileMode)) != NULL)
	{
		retVal = fwrite((void*)iDataPtr, sizeof(int), 1, filePtr);

		if (retVal > 0) // if successful
		{
			printf("File written: %s\n", cFileName);
			printf("retVal: %d\n", retVal);
		}
		else // failed to write
		{
			// if there is an error number
			if (iErr = ferror(filePtr))
			{
				printf("Error writing to file %s: %s\n", cFileName, strerror(iErr));
			}
			else // no error number
			{
				printf("Could not write the data\n");
			}
		}

		// Close the file when done
		fclose(filePtr);
		printf("%s was successfully opened and closed.\n", cFileName);
	}
	else // failed to open the file for writing
	{
		iErr = errno;
		printf("Error accessing the file %s: %s\n", cFileName, strerror(iErr));
	}

	return iErr;
}


int exerciseBinaryWrite(const char* cFileName, const char* cFileMode)
{
	FILE* filePtr = NULL;
	int iErr = 0;
	int iSin, retSin, retName;
	char cNameArray[MAX_NAME_SIZE];
	short sNumRecords = NUM_RECORDS;

	if ((filePtr = fopen(cFileName, cFileMode)) != NULL)
	{
		// Write out the number of records
		// Could check return value to check for successful write
		fwrite((void*)&sNumRecords, sizeof(short), 1, filePtr);

		for (int var = 0; var < NUM_RECORDS; var++)
		{
			// Prompt user for SIN number
			printf("Enter SIN number: ");
			scanf("%d", &iSin); // or "%i" - same as "%d"

			// Clear the stdin buffer of the newline character
			// Note that this will only work if the user hit return immediately after
			// entering the SIN, not if there are more characters - could use loop instead
			getc(stdin);

			// Get the name
			printf("Enter the name: ");
			// Safe way to get a string - however, fgets reads in the newline!
			//fgets(cNameArray, MAX_NAME_SIZE, stdin);
			gets_s(cNameArray, MAX_NAME_SIZE);

			retSin = fwrite((void*)&iSin, sizeof(int), 1, filePtr);
			retName = fwrite((void*)cNameArray, sizeof(char) * MAX_NAME_SIZE, 1, filePtr);

			if (retSin == 0 || retName == 0)
			{
				if (iErr = ferror(filePtr))
				{
					printf("Error writing the file %s: %s\n", cFileName, strerror(iErr));
				}
				else
				{
					printf("Could not write data\n");
				}
			}
		}

		fclose(filePtr);
	}
	else // failed to open file
	{
		iErr = errno;
		printf("Error accessing the file %s: %s\n", cFileName, strerror(iErr));
	}

	return iErr;
}


int exerciseBinaryRead(const char* cFileName, const char* cFileMode, int iSeek)
{
	FILE* filePtr = NULL;
	int iErr = 0;
	int iSin, retSin, retName;
	char cNameArray[MAX_NAME_SIZE];
	short sNumRecords = 0;
	int found = 0;

	if ((filePtr = fopen(cFileName, cFileMode)) != NULL)
	{
		// Read in the number of recrods
		fread((void*)&sNumRecords, sizeof(short), 1, filePtr);

		// Loop through the records until the required id is found
		for (int var = 0; var < sNumRecords && !found; var++)
		{
			// Read in the SIN#
			fread((void*)&iSin, sizeof(int), 1, filePtr);
			if (iSin == iSeek)
			{
				// Read the name in from the file, quit looping as well
				found = fread((void*)cNameArray, MAX_NAME_SIZE, 1, filePtr);
				printf("The name is %s\n", cNameArray);
			}
			else
			{
				fseek(filePtr, MAX_NAME_SIZE, SEEK_CUR);
			}
		}
		if (!found)
		{
			printf("SIN# not found!!!\n");
		}
		// Close the file
		fclose(filePtr);
	}
	else
	{
		printf("Could not open file\n");
	}

	// Not really setting this yet, but you (the student) can do this boring task as an exercise
	return iErr;
}
