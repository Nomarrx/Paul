#include <stdio.h>
#include <stdlib.h>
#include <string.h>


// Note the declaration of a pointer in C. It uses the * operator.
// Pointers are 32 bits or 4 bytes when compiling to an x86 system.
// Pointers are 64 bits or 8 bytes when compiling to an x64 system.
void readString(char* cPtr, char* cLengthPtr);
void printString(char* cPtr);
void readNumbers(int* iPtr);
void printNumbers(int* iPtr, int iSize);
void readStringGets(char* cPtr, int iBufferSize);
char* readStringReturnBuffer();


int main()
{
	// Create buffers to put data into
	char cArray[10];
	char cArray2[10];
	int iReturns;
	int iArray[5];
	int iSize;
	int x = 0;
	int c;
	char* cPtr = NULL;

	// Test 1 - use scanf to input a string
//	printf("Enter a string: ");
//	iReturns = scanf("%s", cArray); // scanf is dangerous; scanf_s provides guards
	// To use scanf, go to Properties | C/C++ | Preprocessor:
	// Preprocessor Definitions: _CRT_SECURE_NO_WARNINGS
//	iReturns = scanf("%9s", cArray);
	// scanf %s should include the maximum size of the string as a modifier
	// This size should not include the null terminator

//	printf("%s\n", cArray);
//	printf("%d\n", iReturns);

//	printf("Enter another string: ");
//	iReturns = scanf_s("%9s", cArray, (unsigned)sizeof(cArray));

//	printf("%s\n", cArray);
//	printf("%d\n", iReturns);

	// Let's do input from a separate function
//	readString(cArray, "5");
	// Let's do output from a separate function
//	printString(cArray);

	// Test 2 - scanf with multiple values
	// The format specifier specifies two string in this case
//	printf("Enter two strings separated by a space: ");
//	scanf("%4s %4s", cArray, cArray2);

//	printString(cArray);
//	printString(cArray2);

	// Test 3 - read in some integers
//	readNumbers(iArray); // should really pass in the size of array
						 // readNumbers is poorly written here
	// How to calculate the size of an array in C:
	// Must be calculated in the same scope where it is declared
	// If you need the size elsewhere, pass it to whatever function you are using.
//	iSize = sizeof(iArray) / sizeof(int);
//	printNumbers(iArray, iSize);

	// Test 4 - use gets() to input a string
	printf("Enter an int: ");
	scanf("%d", &x); // must take address of x so that scanf can change x in main
	printf("You entered %d\n", x);
	// Must clear the input buffer after doing a scanf and before doing a gets_s
	// scanf quits reading when it sees \n on the stdin (input buffer);
	// however, it leaves the newline in stdin
//	getc(stdin); // Gets a character from the stream passed into it
//	getchar(); // Gets a character from the stdin stream

	// clear the buffer
	c = getchar();
	while (c != '\n' && c != EOF)
	{
		c = getchar();
	}
	// Alternative formulation of reading a character until a newline is found:
	// Note the empty loop body - everything is being done inside the while condition
//	while (getchar() != '\n')
//	{
//	}

	readStringGets(cArray, sizeof(cArray) / sizeof(char));
	printString(cArray);

	// Test 5 - returning an array (buffer) - not a good idea
	cPtr = readStringReturnBuffer();
	printString(cPtr);

	return EXIT_SUCCESS;
}


void readString(char* cPtr, char* cLengthPtr)
{
	// Create a format specifier
	char cFormat[4];
	// Initialize cFormat as an empty string
	cFormat[0] = '\0';

	// Use string concatenation to build up the format specifier
	strcat(cFormat, "%");
	strcat(cFormat, cLengthPtr);
	strcat(cFormat, "s");

	printf("Enter a string: ");
	// Note that scanf takes a format specifier (string) as a parameter,
	// and a pointer to a buffer (memory space) as the second parameter.
	// Note that scanf quits reading after the first white space character in a string.
	// Note that the "9" in cLengthPtr limits input to 9 characters not including
	// the null terminator (safer).
	// Because we are passing in "9", this works out to scanf("%9s", cPtr);
	scanf(cFormat, cPtr);
}


void printString(char* cPtr)
{
	char someString[] = "Some arbitrary string";

	printf("The result of reading in the string is:\n");
	printf("%s\n", cPtr);
}


void readNumbers(int* iPtr)
{
	printf("Enter 5 numbers: ");
	// This function will actually read numbers until a non-number is entered
	// regardless of how many numbers are entered - could write past the buffer passed in

	// Note that scanf returns the number of reads that were successful.
	// If it returns 0, no reads were successful.
	// Recall that 0 is false in C.
	while (scanf("%d", iPtr))
	{
		// Move the pointer to the next integer using pointer math.
		// Note that + 1 means "Add one integer's worth of bytes",
		// so in this case, we add 4 to the address in iPtr.
		iPtr = iPtr + 1;
	}
}


void printNumbers(int* iPtr, int iSize)
{
	// This won't work. The size of a pointer is ALWAYS 4 bytes on an x86 system
	// or 8 bytes on an x64 system.
	// Size must be passed in.
//	iSize = sizeof(iPtr) / sizeof(int);

	printf("The numbers to be printed are:\n");
	for (int i = 0; i < iSize; i++)
	{
//		printf("%d\n", *iPtr); 
		// deference iPtr to get the value at that address (pointed to)
		
//		iPtr = iPtr + 1;

		// or just use array notation:
		printf("%d\n", iPtr[i]);
	}
}


void readStringGets(char* cPtr, int iBufferSize)
{
	printf("Enter a big honking string: ");
//	gets(cPtr); // gets ("get string") is considered a dangerous function because
				// it will read past the end of the buffer passed to it
	gets_s(cPtr, iBufferSize); // will not read past bufferSize - invalid parameter handler
}


char* readStringReturnBuffer()
{
	// Memory is allocated on the stack - bad idea because stack frame is popped off
	// when the function is done.
	// Pass in the buffer instead OR dynamically allocate memory on the heap (malloc)
	char cBuffer[256];

	printf("Enter a big string, honking or not: ");
	gets_s(cBuffer, sizeof(cBuffer) / sizeof(char));

	// We are returning the address of memory on the stack!!!!
	// This is a Bad Idea, because the stack frame will be overwritten when
	// some other function gets called.
	return cBuffer;
}
