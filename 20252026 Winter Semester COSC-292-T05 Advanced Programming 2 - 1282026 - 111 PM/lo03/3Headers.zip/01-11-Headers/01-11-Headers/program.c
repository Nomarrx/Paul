#include <stdio.h>
#include "pingpong.h"
// include local files with "" so function prototypes are known ahead of use


int main(void)
{
	ping();
	return 0;
}
