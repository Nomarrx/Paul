// Use Header Guards to prevent these prototypes from being added
// more than once in a file
//#pragma once // will ensure that the file is only loaded once
#ifndef PINGPONG_H // If Not Defined (will be true the first time it is encountered)
#define PINGPONG_H // Define (makes the ifndef false every other time)

// Must write function prototypes to indicate that these functions
// are coded somewhere in the project
void ping();
void pong(); // semicolons after function prototypes

#endif // End the ifndef
