#include <stdbool.h>
#include "memory.h"


void main(void)
{
	float pi = 3.14159f;
	memoryMap(pi);

	c99bool();
}


void c99bool()
{
	// In ANSI C version 99 (from 1999) and up,
	// there is a boolean type called _Bool.
	// It still stores integer values (either 0 or 1).
	_Bool a = 3; // any non-zero integer is still true, prints as 1
	printf("Boolean a: %d\n", a);

	// We can use the <stdbool.h> header file to define
	// bool (which is just _Bool redefined),
	// true (which is really 1), and false (which is really 0)
	bool b = false;
	printf("Boolean b: %d\n", b);
}
