#ifndef MEMORY_H
#define MEMORY_H

// Prototype the function. Note that the formal parameter name is optional. 
int memoryMap(float);
void c99bool();

#endif // !MEMORY_H
