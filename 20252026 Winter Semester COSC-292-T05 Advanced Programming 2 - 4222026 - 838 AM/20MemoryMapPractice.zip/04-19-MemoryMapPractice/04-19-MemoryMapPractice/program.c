#include <stdio.h>
#include <stdlib.h>

#pragma pack(push)
#pragma pack(1)
typedef struct
{
	char c1;
	int i1;
	int i2;
	char c2;
} sampleStruct;
#pragma pack(pop)

void main(void)
{
	int* iPtr = NULL;
	int iArray[] = { 0x12345678, 0x99887766, 0x01020304 };
	char cArray[] = "Hello";
	char* cPtr = NULL;
	sampleStruct s1 = { 'a', 1, 2, 'b' };
	sampleStruct* sPtr = &s1;

	printf("&iPtr: %p\n", &iPtr);
	printf("&iArray: %p\n", &iArray);
	printf("&cArray: %p\n", &cArray);
	printf("&cPtr: %p\n", &cPtr);
	printf("&s1 (Location of struct s1): %p\n", &s1);
	printf("&sPtr (Location of struct pointer sPtr): %p\n", &sPtr);

	cPtr = (char*)iArray;
	printf("cPtr: %p\n", cPtr);

	iPtr = iArray + 2;
	printf("iPtr: %p\n", iPtr);

	printf("*iPtr: %x\n", *iPtr);

	printf("cArray + 2: %p\n", cArray + 2);
	printf("*(cArray + 1): %c %x\n", *(cArray + 1), *(cArray + 1));
	printf("*cArray + 2: %c %x\n", *cArray + 2, *cArray + 2);

	printf("Size of struct: %zu\n", sizeof(sampleStruct));

	printf("Struct's first character from variable: %c\n", s1.c1);
	printf("Struct's second character from pointer: %c\n", sPtr->c2);
	printf("Value of struct pointer sPtr: %p\n", sPtr);
	printf("Location of s1.i1: %p %p\n", &s1.i1, &sPtr->i1);
	printf("Location of s1.i2: %p %p\n", &s1.i2, &sPtr->i2);
}
