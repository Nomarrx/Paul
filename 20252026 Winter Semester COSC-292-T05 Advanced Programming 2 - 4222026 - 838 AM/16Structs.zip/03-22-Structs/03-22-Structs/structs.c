#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include "structs.h"


void DisplayBirthDateBasic(struct BirthDate bd)
{
	printf("\nName is %s\n", bd.cName);
	printf("Gender is %c\n", bd.cGender);
	printf("Date is %d %d %d\n", bd.day, bd.month, bd.year);
}


void DisplayBirthDateTypedef(BirthDateTD bd)
{
	printf("\nName is %s\n", bd.cName);
	printf("Gender is %c\n", bd.cGender);
	printf("Date is %d %d %d\n", bd.day, bd.month, bd.year);
}


void AlterBirthDate(BirthDateTD bd)
{
	printf("\nSize of passed in BirthDateTD is %zd\n", sizeof(bd)); // size 18
	bd.year = 2001;
	DisplayBirthDateTypedef(bd); // will display 2001
}


void AlterBirthDateByRef(BirthDateTD* bdPtr)
{
	printf("\nSize of passed in bdPtr: %zd\n", sizeof(bdPtr)); // size 8 (x64) or 4 (x86)
	//(*bdPtr).year = 2023;
	bdPtr->year = 2022;
}


// A function that creates a student and initializes the attributes. This is similar to the
// keyword new in C# or Java. It allocates the instance AND it is also like a constructor
// that sets all the attributes.
student* CreateStudent(char* cNamePtr, int iStudentNum, int* iMarksPtr, int iMarkCount)
{
	// Allocate a student on the heap
	student* sPtr = (student*)malloc(sizeof(student));

	if (sPtr != NULL)
	{
		// Allocate room for the name
		sPtr->cNamePtr = malloc((strlen(cNamePtr) + 1) * sizeof(char));
		strcpy(sPtr->cNamePtr, cNamePtr);

		// Assign student number
		sPtr->iStudentNum = iStudentNum;

		// Marks array
		sPtr->iMarksPtr = malloc(iMarkCount * sizeof(int));
		memcpy(sPtr->iMarksPtr, iMarksPtr, iMarkCount * sizeof(int));

		// Set the number of marks
		sPtr->iMarkCount = iMarkCount;
	}

	return sPtr;
}


// A function to display the date stored in a student instance.
// Takes a student instance, not a pointer. Sometimes this is done as a copy of the student
// is made. If this funciton messes up the struct somehow, it will not mess up the struct
// passed in.
void DisplayStudent(student s)
{
	printf("\nName: %s\n", s.cNamePtr);
	printf("Student number: %d\n", s.iStudentNum);
	printf("Marks: ");
	for (int i = 0; i < s.iMarkCount; i++)
	{
		printf("%d ", s.iMarksPtr[i]);
	}
	printf("\n");
}


// This function will free the memory allocated for a student instance.
// In C++, there is a function called a destructor where the programmer is
// supposed to release memory and clean up any other resources - this is similar.
void FreeStudent(student* sPtr)
{
	free(sPtr->cNamePtr);
	sPtr->cNamePtr = NULL;

	free(sPtr->iMarksPtr);
	sPtr->iMarksPtr = NULL;

	// Do we free the struct itself? Only if the struct is dynamically allocated.
	// This is a design decision.
	free(sPtr);
	sPtr = NULL;
}


// Get student data from the user
student* GetStudent()
{
	char cName[MAX_NAME_SIZE];
	int iMarks[2];
	int iStudentNum;

	// Get the name
	printf("Enter the student name: ");
	gets_s(cName, MAX_NAME_SIZE);

	// Get the student number
	printf("Enter the student number: ");
	scanf("%d", &iStudentNum);

	printf("Enter two marks, separated by a space: ");
	scanf("%d %d", iMarks, iMarks + 1);
	getc(stdin); // Clear any newline characters for next time

	return CreateStudent(cName, iStudentNum, iMarks, 2);
}


// Ask the user to populate the classroom. First ask how many students.
// Then ask for data for each student.
classroom PopulateClassroom()
{
	// Create an instance of the classroom on the stack
	classroom c;

	printf("Enter number of students: ");
	scanf("%hu", &c.sNumStudents);
	getc(stdin);

	// Need to allocate space for the array of student pointers
	c.sPtrPtr = (student**)malloc(c.sNumStudents * sizeof(student*));

	for (int i = 0; i < c.sNumStudents; i++)
	{
		c.sPtrPtr[i] = GetStudent();
	}

	return c;
}


// Display each student in the classroom
void DisplayClassroom(classroom c)
{
	for (int i = 0; i < c.sNumStudents; i++)
	{
		DisplayStudent(*c.sPtrPtr[i]);
	}
}


void FreeClassroom(classroom* classPtr)
{
	// Free students
	for (int i = 0; i < classPtr->sNumStudents; i++)
	{
		FreeStudent(classPtr->sPtrPtr[i]);
		classPtr->sPtrPtr[i] = NULL;
	}

	// Free classroom
	free(classPtr->sPtrPtr);
	classPtr->sPtrPtr = NULL;
}
