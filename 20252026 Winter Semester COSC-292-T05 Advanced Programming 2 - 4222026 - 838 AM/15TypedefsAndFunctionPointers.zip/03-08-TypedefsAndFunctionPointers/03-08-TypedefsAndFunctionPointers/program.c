#include <stdio.h>
#include <stdlib.h>
#include "funcs.h"


void testTypedefs()
{
	Length x = 3;
	Length y = 5;
	printf("x plus y = %d\n", x + y);

	String p;
	p = "Hello World";
	printf("The string is %s\n", p);
	printf("The first character is %c\n", *p);

	Ushort s = 60000;
	printf("The value of s is %hu\n", s);
}


int doSquare(int x)
{
	return x * x;
}


int doAdd(int x)
{
	return x + x;
}


int doNothing(int someNumber)
{
	return someNumber;
}


// Do we need to match the signature of the function pointer?
// No, it will still compile and run.
// You need to make sure that there are no conversion errors from one type to the next.
// In general, using functions that do not have matching signatures is not a good idea.
int dontMatchSignature(short x)
{
	return (int)x;
}


int compareToAscending(int first, int second)
{
	return first - second;
}


int compareToDescending(int a, int b)
{
	return b - a;
}


int main()
{
	int iArray[] = { 45, 56, 62, 30, 2 };
	int iSize = sizeof(iArray) / sizeof(int);

	size_t someVariable; // size_t is set with typedef in <stdio.h> and <stdlib.h>
						 // different settings (unsigned int vs. unsigned long long)
						 // for different environments (x86 vs. x64)

	//testTypedefs();

	// Note that we pass a function into iterateNumbers as the last parameter.
	// The name of the function stores its address so we don't need &.
	iterateNumbers(iArray, iSize, doSquare);
	iterateNumbers(iArray, iSize, &doAdd);
	iterateNumbers(iArray, iSize, doNothing);
	iterateNumbers(iArray, iSize, dontMatchSignature);

	sortInts(iArray, iSize, compareToDescending);
	for (int i = 0; i < iSize; i++)
	{
		printf("%d ", iArray[i]);
	}
	printf("\n");

	return EXIT_SUCCESS;
}
