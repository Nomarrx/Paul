#include <stdio.h>
#include "mathfuncs.h"


void display(double dAverage, double dStdDeviation)
{
	printf("Average = %-10.21f\n", dAverage);
	printf("St.Dev. = %-10.21f\n", dStdDeviation);
}
