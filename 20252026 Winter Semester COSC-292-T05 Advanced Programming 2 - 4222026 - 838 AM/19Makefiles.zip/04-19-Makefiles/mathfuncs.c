#include <math.h>
#include "mathfuncs.h"


double average(double data[], int iSize)
{
	int i = 0;
	double dSum = 0.0;

	for (i = 0; i < iSize; i++)
	{
		dSum += data[i];
	}

	return dSum / iSize;
}


double stDev(double data[], int iSize)
{
	double dAvg = average(data, iSize);
	int i = 0;
	double dSum = 0.0;

	for (i = 0; i < iSize; i++)
	{
		dSum += square(data[i] - dAvg);
	}

	return sqrt(dSum / (iSize - 1));
}


double square(double dNum)
{
	return dNum * dNum;
}
