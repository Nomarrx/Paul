#include <stdio.h>
#include <stdlib.h> // includes malloc function
#include <string.h> // for strlen and strcpy/strcpy_s

#define MAXLENGTH	100

/*
Here's a couple of midterm review questions. The first involves writing a function (your 3 coding questions 
on the exam will each involve writing a function), and the second involves calling that function from main 
(or some testing function).

1.	Create a function getName that will prompt the user to type in a name with some possible maximum length 
(say #define MAXLENGTH 100). The function should then return dynamically allocated memory of just the size 
necessary for the name entered. The function should also alter two variables passed in so that the calling 
function will have the length of the string (without the null terminator) and a pointer to the last character 
in the string (assume that there is at least one character in the string). So for instance, if the user enters 
"Mike", it should return 5 bytes of dynamically allocated memory containing Mike (including the null terminator) 
and change the length variable to 4 and the pointer to point to the "e" in Mike.

2.	Call the function getName and then use the pointer to the last character in the string and the length of the 
string to print out the name backwards (one character at a time). Then print out the name as ints instead of 
chars (for each 4 chars, print out 1 int - don't worry about extra characters that are not in groups of 4). So 
for instance, if the user entered "Grzesina", it should print out "anisezrG" and 2 ints (one with the value 
corresponding to "Grze" and one with the value corresponding to "sina").

I will post a sample solution later in the Exercises folder on the OneDrive folder.
*/


/*
SAMPLE INTPUT/OUTPUT:
Enter a name: Mike
ekiM
1701538125

Enter a name: Grzesina
anisezrG
1702523463
1634625907

Enter a name: Michael Grzesina
anisezrG leahciM
1751345485
543974753
1702523463
1634625907
*/

char* getName(int* lengthPtr, char** lastLetterPtrPtr)
{
	char nameBuffer[MAXLENGTH];
	char* namePtr = NULL;

	printf("Enter a name: ");
	gets_s(nameBuffer, MAXLENGTH); // could use scanf - gets_s allows spaces and safely inputs data
	//scanf("%s", nameBuffer); // would require project properties preprocessor definition _CRT_SECURE_NO_WARNINGS
	//scanf_s("%99s", nameBuffer, MAXLENGTH); // alternative safe version

	*lengthPtr = strlen(nameBuffer); // get length of name entered and change value in calling function
	namePtr = (char*)malloc(*lengthPtr + 1); // allocate space for name including null terminator
	if (namePtr != NULL) // can test if malloc succeeded if desired
	{
		strcpy_s(namePtr, *lengthPtr + 1, nameBuffer);
		//strcpy(namePtr, nameBuffer); // would require project properties preprocessor definition _CRT_SECURE_NO_WARNINGS
		*lastLetterPtrPtr = namePtr + *lengthPtr - 1; // set pointer to last letter using pointer math
	}

	return namePtr;
}


int main(int argc, char* argv[])
{
	int iLength;
	char* lastCharacterPtr = NULL;
	char* myName = getName(&iLength, &lastCharacterPtr);
	int iNumInts;
	int* intPtr = NULL;

	for (int i = iLength; i > 0; i--)
	{
		printf("%c", *lastCharacterPtr--);
	}
	// alternative formulation without using iLength - just keep going until start of name
	//do {
	//	printf("%c", *lastCharacterPtr);
	//} while (lastCharacterPtr-- != myName);
	printf("\n");

	intPtr = (int*)myName;
	iNumInts = iLength / sizeof(int); // integer division
	for (int i = 0; i < iNumInts; i++)
	{
		printf("%d\n", *intPtr++); // or do %x to see the hex values and check that they match the ASCII equivalents
		//printf("%d\n", intPtr[i]); // alternative without walking intPtr; or use *(intPtr + i)
	}

	free(myName);
	myName = NULL;
}
