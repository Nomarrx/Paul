#include <stdlib.h>
#include "mathfuncs.h"


int main(void)
{
	double data[] = { 12.0, 13.6, 12.4, 10.9, 100.0 };
	double dAvg, dStDev;
	int iSize = sizeof(data) / sizeof(double);

	dAvg = average(data, iSize);
	dStDev = stDev(data, iSize);

	display(dAvg, dStDev);

	return EXIT_SUCCESS;
}
