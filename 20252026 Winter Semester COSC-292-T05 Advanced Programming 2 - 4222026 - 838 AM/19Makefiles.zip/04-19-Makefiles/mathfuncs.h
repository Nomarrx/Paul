#ifndef MATHFUNCS_H
#define MATHFUNCS_H

double average(double data[], int iSize);
double stDev(double data[], int iSize);

double square(double dNum);

void display(double, double);

#endif // !MATHFUNCS_H
